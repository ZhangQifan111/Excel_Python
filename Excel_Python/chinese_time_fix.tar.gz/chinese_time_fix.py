# 修复 excel_data_visualizer.py 中文时间格式问题
# 替换约第 6191-6195 行的代码

            # 【修复】处理中文时间格式 (如 "7时51分58秒" -> datetime)
            if not pd.api.types.is_datetime64_any_dtype(self.df[self.time_column]):
                # 先尝试直接转换
                self.df[self.time_column] = pd.to_datetime(self.df[self.time_column], errors='coerce')
                
                # 如果转换失败（全是NaT），尝试中文时间格式转换
                if self.df[self.time_column].isna().all():
                    import re
                    def parse_chinese_time(t):
                        if pd.isna(t):
                            return pd.NaT
                        t = str(t)
                        # 匹配 "7时51分58秒" 或 "07时51分58秒" 格式
                        match = re.match(r'(\d{1,2})时(\d{1,2})分(\d{1,2})秒', t)
                        if match:
                            h, m, s = match.groups()
                            try:
                                # 构造标准时间格式，用今天作为日期
                                return pd.to_datetime(f"2024-01-01 {int(h):02d}:{int(m):02d}:{int(s):02d}")
                            except:
                                return pd.NaT
                        return pd.NaT
                    
                    self.df[self.time_column] = self.df[self.time_column].apply(parse_chinese_time)
                
                # 删除转换失败的行
                self.df = self.df.dropna(subset=[self.time_column])